package edu.common.dynamicextensions.domaininterface.userinterface;

/**
 * CheckBox interface stores necessary information for generating checkbox control on
 * dynamically generated user interface.  
 * @author geetika_bangard
 */
public interface CheckBoxInterface extends ControlInterface 
{
    
   
    
}
