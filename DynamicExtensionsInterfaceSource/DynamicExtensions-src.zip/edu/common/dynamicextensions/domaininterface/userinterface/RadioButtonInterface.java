package edu.common.dynamicextensions.domaininterface.userinterface;
/**
 * RadioButtonInterface stores necessary information for generating RadioButton control on
 * dynamically generated user interface.  
 * @author geetika_bangard
 */
public interface RadioButtonInterface extends ControlInterface 
{
    
}
