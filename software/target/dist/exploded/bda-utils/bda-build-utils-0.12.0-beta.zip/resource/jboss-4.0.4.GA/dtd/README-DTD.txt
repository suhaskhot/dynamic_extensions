# $Id: README-DTD.txt 1502 2009-04-06 15:51:50Z saksass $
The following files contained witin this folder are covered by license terms
documented in docs/licenses/sun-specs.txt of the distribution.

application_1_2.dtd
application_1_3.dtd
application-client_1_3.dtd
connector_1_0.dtd
ejb-jar.dtd
ejb-jar_2_0.dtd
web-app_2_2.dtd
web-app_2_3.dtd

More details on using these J2EE Schemas are available at:
java.sun.com/xml/ns/j2ee/#usage
